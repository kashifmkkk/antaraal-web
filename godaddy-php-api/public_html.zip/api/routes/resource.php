<?php

function api_resource_route(PDO $pdo, string $resource, array $segments = []): void
{
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $id = isset($segments[0]) && ctype_digit((string) $segments[0]) ? (int) $segments[0] : null;

    if ($method === 'GET') {
        switch ($resource) {
            case 'products':
                if ($id !== null) {
                    $rows = api_query_all(
                        $pdo,
                        'SELECT p.id, p.name, p.category, p.category_id AS categoryId, p.image, p.photos, p.description, p.reference_code AS referenceCode, p.vendor, p.price, p.availability, p.warranty, p.warranty_status AS warrantyStatus, p.rating, p.review_count AS reviewCount, p.status, p.warranty_expiry AS warrantyExpiry, p.created_at AS createdAt, p.updated_at AS updatedAt, c.slug AS categorySlug
                         FROM products p
                         LEFT JOIN categories c ON c.id = p.category_id
                         WHERE p.id = :id
                         LIMIT 1',
                        ['id' => $id]
                    );
                    $row = $rows[0] ?? null;
                    if (!$row) {
                        api_json(['error' => 'not_found'], 404);
                    }

                    $row['categoryId'] = $row['categoryId'] !== null ? (int) $row['categoryId'] : null;
                    $row['photos'] = api_json_decode_array($row['photos'] ?? null);
                    $row['rating'] = $row['rating'] !== null ? (float) $row['rating'] : null;
                    $row['reviewCount'] = (int) ($row['reviewCount'] ?? 0);
                    $row['warrantyExpiry'] = $row['warrantyExpiry'] ?? null;
                    api_json($row);
                }

                $products = api_query_all(
                    $pdo,
                    'SELECT p.id, p.name, COALESCE(NULLIF(p.category, \'\'), c.name) AS category, p.category_id AS categoryId, p.image, p.photos, p.description, p.reference_code AS referenceCode, p.vendor, p.price, p.availability, p.warranty, p.warranty_status AS warrantyStatus, p.rating, p.review_count AS reviewCount, p.status, p.warranty_expiry AS warrantyExpiry, p.created_at AS createdAt, p.updated_at AS updatedAt
                     FROM products p
                     LEFT JOIN categories c ON c.id = p.category_id
                     ORDER BY p.updated_at DESC, p.id DESC'
                );

                foreach ($products as &$product) {
                    $product['categoryId'] = $product['categoryId'] !== null ? (int) $product['categoryId'] : null;
                    $product['photos'] = api_json_decode_array($product['photos'] ?? null);
                    $product['rating'] = $product['rating'] !== null ? (float) $product['rating'] : null;
                    $product['reviewCount'] = (int) ($product['reviewCount'] ?? 0);
                    $product['warrantyExpiry'] = $product['warrantyExpiry'] ?? null;
                }

                api_json($products);

            case 'categories':
                if ($id !== null) {
                    $rows = api_query_all(
                        $pdo,
                        'SELECT c.id, c.name, c.slug, c.description, c.is_active AS isActive, c.created_at AS createdAt, c.updated_at AS updatedAt, COUNT(p.id) AS productCount
                         FROM categories c
                         LEFT JOIN products p ON p.category_id = c.id
                         WHERE c.id = :id
                         GROUP BY c.id
                         LIMIT 1',
                        ['id' => $id]
                    );
                    $row = $rows[0] ?? null;
                    if (!$row) {
                        api_json(['error' => 'not_found'], 404);
                    }
                    $row['isActive'] = (bool) $row['isActive'];
                    $row['productCount'] = (int) $row['productCount'];
                    api_json($row);
                }

                $categories = api_query_all(
                    $pdo,
                    'SELECT c.id, c.name, c.slug, c.description, c.is_active AS isActive, c.created_at AS createdAt, c.updated_at AS updatedAt, COUNT(p.id) AS productCount
                     FROM categories c
                     LEFT JOIN products p ON p.category_id = c.id
                     GROUP BY c.id
                     ORDER BY c.name ASC'
                );

                foreach ($categories as &$category) {
                    $category['isActive'] = (bool) $category['isActive'];
                    $category['productCount'] = (int) $category['productCount'];
                }

                api_json($categories);

            case 'vendors':
                if ($id !== null) {
                    $rows = api_query_all(
                        $pdo,
                        'SELECT id, name, location, rating, specialty, image, verification_status AS verificationStatus, is_active AS isActive, certifications, created_at AS createdAt, updated_at AS updatedAt
                         FROM vendors
                         WHERE id = :id
                         LIMIT 1',
                        ['id' => $id]
                    );
                    $row = $rows[0] ?? null;
                    if (!$row) {
                        api_json(['error' => 'not_found'], 404);
                    }
                    $row['rating'] = $row['rating'] !== null ? (float) $row['rating'] : null;
                    $row['isActive'] = (bool) $row['isActive'];
                    $row['certifications'] = api_json_decode_array($row['certifications'] ?? null);
                    api_json($row);
                }

                $vendors = api_query_all(
                    $pdo,
                    'SELECT id, name, location, rating, specialty, image, verification_status AS verificationStatus, is_active AS isActive, certifications, created_at AS createdAt, updated_at AS updatedAt
                     FROM vendors
                     ORDER BY name ASC'
                );

                foreach ($vendors as &$vendor) {
                    $vendor['rating'] = $vendor['rating'] !== null ? (float) $vendor['rating'] : null;
                    $vendor['isActive'] = (bool) $vendor['isActive'];
                    $vendor['certifications'] = api_json_decode_array($vendor['certifications'] ?? null);
                }

                api_json($vendors);

            case 'notifications':
                $user = api_current_user($pdo);
                if (!$user) {
                    api_json([]);
                }

                $params = ['userId' => (int) $user['id']];
                $vendorId = $user['vendor_id'] !== null ? (int) $user['vendor_id'] : null;
                $where = '(n.user_id = :userId';
                if ($vendorId !== null) {
                    $where .= ' OR n.vendor_id = :vendorId';
                    $params['vendorId'] = $vendorId;
                }
                $where .= ')';

                $since = trim((string) ($_GET['since'] ?? ''));
                if ($since !== '') {
                    $where .= ' AND n.created_at > :since';
                    $params['since'] = $since;
                }

                $notifications = api_query_all(
                    $pdo,
                    'SELECT n.id, n.title, n.body, n.user_id AS userId, n.vendor_id AS vendorId, n.product_id AS productId, n.is_read AS isRead, n.created_at AS createdAt,
                            u.name AS userName, u.email AS userEmail, v.name AS vendorName, v.location AS vendorLocation, p.name AS productName
                     FROM notifications n
                     LEFT JOIN users u ON u.id = n.user_id
                     LEFT JOIN vendors v ON v.id = n.vendor_id
                     LEFT JOIN products p ON p.id = n.product_id
                     WHERE ' . $where . '
                     ORDER BY n.created_at DESC
                     LIMIT 50',
                    $params
                );

                foreach ($notifications as &$notification) {
                    $notification['userId'] = $notification['userId'] !== null ? (int) $notification['userId'] : null;
                    $notification['vendorId'] = $notification['vendorId'] !== null ? (int) $notification['vendorId'] : null;
                    $notification['productId'] = $notification['productId'] !== null ? (int) $notification['productId'] : null;
                    $notification['isRead'] = (bool) $notification['isRead'];
                    $notification['user'] = $notification['userName'] !== null ? [
                        'name' => $notification['userName'],
                        'email' => $notification['userEmail'],
                    ] : null;
                    $notification['vendor'] = $notification['vendorName'] !== null ? [
                        'name' => $notification['vendorName'],
                        'location' => $notification['vendorLocation'],
                    ] : null;
                    unset($notification['userName'], $notification['userEmail'], $notification['vendorName'], $notification['vendorLocation'], $notification['productName']);
                }

                api_json($notifications);

            case 'reviews':
                if ($id !== null) {
                    $rows = api_query_all(
                        $pdo,
                        'SELECT r.id, r.product_id AS productId, r.user_id AS userId, r.user_name AS userName, r.rating, r.comment, r.status, r.created_at AS createdAt, r.updated_at AS updatedAt
                         FROM reviews r
                         WHERE r.id = :id
                         LIMIT 1',
                        ['id' => $id]
                    );
                    $row = $rows[0] ?? null;
                    if (!$row) {
                        api_json(['error' => 'not_found'], 404);
                    }
                    $row['productId'] = (int) $row['productId'];
                    $row['userId'] = $row['userId'] !== null ? (int) $row['userId'] : null;
                    $row['rating'] = (int) $row['rating'];
                    api_json($row);
                }

                $productId = isset($segments[0]) && strtolower((string) $segments[0]) === 'product' && isset($segments[1]) && ctype_digit((string) $segments[1])
                    ? (int) $segments[1]
                    : null;

                $sql = 'SELECT r.id, r.product_id AS productId, r.user_id AS userId, r.user_name AS userName, r.rating, r.comment, r.status, r.created_at AS createdAt, r.updated_at AS updatedAt
                        FROM reviews r';
                $params = [];
                if ($productId !== null) {
                    $sql .= ' WHERE r.product_id = :productId';
                    $params['productId'] = $productId;
                }
                $sql .= ' ORDER BY r.created_at DESC, r.id DESC';

                $reviews = api_query_all($pdo, $sql, $params);
                foreach ($reviews as &$review) {
                    $review['productId'] = (int) $review['productId'];
                    $review['userId'] = $review['userId'] !== null ? (int) $review['userId'] : null;
                    $review['rating'] = (int) $review['rating'];
                }

                api_json($reviews);
        }
    }

    switch ($method) {
        case 'GET':
            api_json([
                'resource' => $resource,
                'action' => $id ? 'show' : 'index',
                'id' => $id,
                'message' => 'Replace this stub with a real SELECT query.',
            ]);

        case 'POST':
            api_json([
                'resource' => $resource,
                'action' => 'create',
                'received' => api_input(),
                'message' => 'Replace this stub with INSERT logic.',
            ], 201);

        case 'PUT':
        case 'PATCH':
            api_json([
                'resource' => $resource,
                'action' => 'update',
                'id' => $id,
                'received' => api_input(),
                'message' => 'Replace this stub with UPDATE logic.',
            ]);

        case 'DELETE':
            api_json([
                'resource' => $resource,
                'action' => 'delete',
                'id' => $id,
                'message' => 'Replace this stub with DELETE logic.',
            ]);

        default:
            api_method_not_allowed(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);
    }
}
