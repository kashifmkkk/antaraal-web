<?php

function api_admin_resource_route(PDO $pdo, string $resource, array $segments = []): void
{
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $id = isset($segments[0]) && ctype_digit((string) $segments[0]) ? (int) $segments[0] : null;

    if ($resource === 'inventory' && ($segments[1] ?? '') === 'approve') {
        api_json([
            'resource' => 'inventory',
            'action' => 'approve',
            'id' => $id,
            'message' => 'Replace this stub with product approval logic.',
        ]);
    }

    switch ($method) {
        case 'GET':
            api_json([
                'resource' => $resource,
                'scope' => 'admin',
                'action' => $id ? 'show' : 'index',
                'id' => $id,
                'message' => 'Replace this stub with admin SELECT logic.',
            ]);

        case 'POST':
            api_json([
                'resource' => $resource,
                'scope' => 'admin',
                'action' => 'create',
                'received' => api_input(),
                'message' => 'Replace this stub with admin INSERT logic.',
            ], 201);

        case 'PUT':
        case 'PATCH':
            api_json([
                'resource' => $resource,
                'scope' => 'admin',
                'action' => 'update',
                'id' => $id,
                'received' => api_input(),
                'message' => 'Replace this stub with admin UPDATE logic.',
            ]);

        case 'DELETE':
            api_json([
                'resource' => $resource,
                'scope' => 'admin',
                'action' => 'delete',
                'id' => $id,
                'message' => 'Replace this stub with admin DELETE logic.',
            ]);

        default:
            api_method_not_allowed(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);
    }
}
