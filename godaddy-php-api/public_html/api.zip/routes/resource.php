<?php

function api_resource_route(PDO $pdo, string $resource, array $segments = []): void
{
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $id = isset($segments[0]) && ctype_digit((string) $segments[0]) ? (int) $segments[0] : null;

    switch ($method) {
        case 'GET':
            api_json([
                'resource' => $resource,
                'action' => $id ? 'show' : 'index',
                'id' => $id,
                'message' => 'Replace this stub with a real SELECT query.',
            ]);

        case 'POST':
            api_json([
                'resource' => $resource,
                'action' => 'create',
                'received' => api_input(),
                'message' => 'Replace this stub with INSERT logic.',
            ], 201);

        case 'PUT':
        case 'PATCH':
            api_json([
                'resource' => $resource,
                'action' => 'update',
                'id' => $id,
                'received' => api_input(),
                'message' => 'Replace this stub with UPDATE logic.',
            ]);

        case 'DELETE':
            api_json([
                'resource' => $resource,
                'action' => 'delete',
                'id' => $id,
                'message' => 'Replace this stub with DELETE logic.',
            ]);

        default:
            api_method_not_allowed(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);
    }
}
